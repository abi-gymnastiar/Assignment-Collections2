package yak.assignment_abiansyah;

import java.util.*;

/**
 *
 * @author OWNER
 */
public class Assignment_Abiansyah {

    public static void main(String[] args) {
        
        System.out.println("----SHOPPING LIST USING DIFFERENT METHODS----");
        System.out.println("\n\n");
        
        //using List
        List<String> shoppingList = new ArrayList<>();
 
        shoppingList.add("Orange");
        shoppingList.add("Milk");
        shoppingList.add("Tomato Sauce");
        shoppingList.add("Sausage");
 
        System.out.println("List :");
        for (String fruit : shoppingList)
        {
            System.out.println(fruit);
        }
        System.out.println("");
        
        //using Set
        Set<String> Set = new HashSet<String>();
        Set.add("Orange");
        Set.add("Milk");
        Set.add("Tomato Sauce");
        Set.add("Sausage");
        
        System.out.println("Set :");
        System.out.println(Set);
        System.out.println("");
        
        //using Map
        Map<Integer, String> map = new HashMap<Integer, String>();

        map.put(1, "Orange");
        map.put(2, "Milk");
        map.put(3, "Tomato Sauce");
        map.put(4, "Sausage");
 
        System.out.println("Map :");
        for (Map.Entry m : map.entrySet())
        {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        System.out.println("");
        
        //using LinkedList (Stack)
        LinkedList<String> linkedListStack = new LinkedList<String>();
        linkedListStack.add("Orange");
        linkedListStack.add("Milk");
        linkedListStack.add("Tomato Sauce");
        linkedListStack.add("Sausage");
        
        System.out.println("LinkedList (Stack)");
        System.out.println(linkedListStack);
        System.out.println("After pop");
        linkedListStack.removeLast();
        System.out.println(linkedListStack);
        System.out.println("\n");
        
        //using LinkedList (queue)
        LinkedList<String> linkedListQueue = new LinkedList<String>();
        linkedListStack.add("Orange");
        linkedListStack.add("Milk");
        linkedListStack.add("Tomato Sauce");
        linkedListStack.add("Sausage");
        
        System.out.println("LinkedList (Queue)");
        System.out.println(linkedListStack);
        System.out.println("after dequeue:");
        linkedListStack.remove();
        System.out.println(linkedListStack);
    }
}
